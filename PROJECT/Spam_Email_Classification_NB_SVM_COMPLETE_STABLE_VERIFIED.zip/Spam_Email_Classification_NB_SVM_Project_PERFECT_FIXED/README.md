# Spam Email Classification Using Naive Bayes and SVM

A complete machine-learning web project for Spam/Ham classification using **Multinomial Naive Bayes** and **Support Vector Machine (SVM)**, with model comparison, SVM kernel analysis, hyperparameter tuning, and a responsive cream-and-blue web interface.

## Dataset variables

The project uses the two required dataset columns:

- **X = `v2`** — message text / input feature
- **Y = `v1`** — Spam/Ham target variable

The bundled dataset contains **5,572 raw messages**. After duplicate removal, it contains **5,169 messages: 4,516 Ham and 653 Spam**.

Two copies are included:

- `data/spam.csv` — working dataset
- `data/spam_canonical.csv` — clean local recovery copy

If `spam.csv` is missing, malformed, or from an older five-column version, the project automatically restores it from `spam_canonical.csv`. Normal use does not require downloading the dataset.

## Included features

- Live Spam/Ham classification for newly entered messages
- Naive Bayes and optimized SVM predictions side-by-side
- TF-IDF unigram + bigram feature extraction
- Accuracy, Precision, Recall, F1-Score, Specificity, ROC-AUC, FPR and FNR
- Naive Bayes and SVM confusion matrices
- SVM kernel comparison: Linear, RBF, Polynomial and Sigmoid
- Hyperparameter comparison for `C`, `gamma` and `degree`
- Stratified cross-validation ranked primarily by F1-score
- Automatic selection of the strongest tested SVM configuration
- SVM decision margin and decision-strength visualization
- Influential-word analysis and message profile
- Flask backend + HTML/CSS/JavaScript frontend

The SVM intentionally uses the stable public `predict()` and `decision_function()` APIs. It does **not** depend on SVC probability internals, which avoids cross-version failures such as `_effective_probability` errors.

## Windows quick start

1. Extract the ZIP into a **new folder**.
2. Close CMD windows running older copies of this project.
3. Double-click **`setup_and_run.bat`**.
4. The launcher creates an isolated `.venv` for this project and installs the required packages there.
5. A preflight check validates the dataset and ML artifacts. If the packaged artifacts do not match your installed Python/scikit-learn runtime, they are retrained automatically before the website starts.
6. The correct localhost page opens automatically.

The app prefers port `5000`. If that port is already being used, it selects the next free port and opens the correct address.

## Run after first setup

Double-click:

```text
run.bat
```

## Manual CMD setup

```cmd
cd path\to\project
python -m venv .venv
.venv\Scripts\python.exe -m pip install --upgrade -r requirements.txt
.venv\Scripts\python.exe preflight.py
.venv\Scripts\python.exe app.py
```

## Project structure

```text
project/
├── app.py
├── preflight.py
├── requirements.txt
├── setup_and_run.bat
├── run.bat
├── train_models.bat
├── data/
│   ├── spam.csv
│   ├── spam_canonical.csv
│   └── README.md
├── ml/
│   ├── artifacts.py
│   ├── data.py
│   ├── evaluation.py
│   ├── inference.py
│   ├── runtime.py
│   └── training.py
├── models/
├── results/
├── templates/
│   └── index.html
├── static/
│   ├── css/styles.css
│   └── js/app.js
└── tests/
```

## ML flow

```text
X = v2 message text                Y = v1 Spam/Ham label
        │                                  │
        └──────────────┬───────────────────┘
                       ↓
              Cleaning + duplicates
                       ↓
              80/20 stratified split
                       ↓
                    TF-IDF
                       ↓
          ┌────────────┴────────────┐
          ↓                         ↓
   Multinomial NB              Baseline SVM
          └────────────┬────────────┘
                       ↓
                Metric comparison
                       ↓
               SVM kernel study
        Linear / RBF / Poly / Sigmoid
                       ↓
             Hyperparameter tuning
                C / gamma / degree
                       ↓
                Optimized SVM
                       ↓
                Web classification
```

## Troubleshooting

**`python` is not recognized**  
Install Python 3.11 or newer and enable **Add Python to PATH**.

**The first setup takes some time**  
The preflight may retrain the ML experiment when your runtime differs from the packaged artifact runtime. On the reference environment the full experiment completed in about 24 seconds; laptop speed can vary.

**Port 5000 is already in use**  
Use the page opened automatically or the exact URL printed in CMD. The project searches ports 5000–5019.

**Dataset was accidentally edited**  
Run the project again. Invalid `data/spam.csv` is restored from the bundled `data/spam_canonical.csv`.

**A package was upgraded later**  
Run `setup_and_run.bat` again. Runtime metadata invalidates incompatible cached models and preflight retrains them locally.
